import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;

class MoveActionListener implements ActionListener {
    @Override
    public void actionPerformed(ActionEvent e) {
        Main.t1.parallelMove(100, 100);
        Main.p.repaint();
    }

}


class SaveActionListener implements ActionListener {
    @Override
    public void actionPerformed(ActionEvent e) {
        try {
            FileOutputStream fos = new FileOutputStream("save.dat");
            ObjectOutputStream oos = new ObjectOutputStream(fos);
            oos.writeObject(Main.t1);
        } catch (IOException ex) {
            throw new RuntimeException(ex);
        }
    }

}