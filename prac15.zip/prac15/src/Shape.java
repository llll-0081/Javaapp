import java.awt.*;
import java.io.*;

class Shape {
    int size;
}

class Triangle extends Shape implements Drawable, Movable, Serializable {

    private static final long serialVersionUID = 1123456789L;
    Point p1;
    Point p2;
    Point p3;

    Triangle(Point p1, Point p2, Point p3) {
        this.size = 1;
        this.p1 = p1;
        this.p2 = p2;
        this.p3 = p3;
    }

    @Override
    public void draw(Graphics g) {
        int[] xPoints = {p1.x, p2.x, p3.x};
        int[] yPoints = {p1.y, p2.y, p3.y};
        g.setColor(Color.BLACK); // 黒色に設定
        g.drawPolygon(xPoints, yPoints, 3);
    }

    @Override
    public void parallelMove(int diffX, int diffY) {
        p1.x = p1.x + diffX;
        p2.x = p2.x + diffX;
        p3.x = p3.x + diffX;
        p1.y = p1.y + diffY;
        p2.y = p2.y + diffY;
        p3.y = p3.y + diffY;

    }

    @Override
    public void rotate() {
        System.out.println("回転しました。");
    }

}

class Rectangle extends Shape implements Drawable {

    Point p1;
    Point p2;
    Point p3;

    Point p4;

    Rectangle(Point p1, Point p2, Point p3, Point p4) {
        this.size = 1;
        this.p1 = p1;
        this.p2 = p2;
        this.p3 = p3;
        this.p4 = p4;
    }

    @Override
    public void draw(Graphics g) {
        int[] xPoints = {p1.x, p2.x, p3.x, p4.x};
        int[] yPoints = {p1.y, p2.y, p3.y, p4.y};
        g.drawPolygon(xPoints, yPoints, 4);
    }
}


interface Drawable {
    void draw(Graphics g);
}


interface ParallelMovable {
    void parallelMove(int diffX, int diffY);
}

interface Movable extends ParallelMovable{
    void rotate();
}