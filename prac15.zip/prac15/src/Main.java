
import javax.swing.*;
import java.awt.*;
import java.io.*;

public class Main {
    public static Triangle t1;
    public static Rectangle r1;
    public static MyPanel p;

    public static void main(String[] args) throws IOException, ClassNotFoundException {
        JFrame frame = new JFrame();
        frame.setSize(400,600);
        Main.p = new MyPanel();
        File file = new File("save.dat");
        if (file.exists()) {
            FileInputStream fis = new FileInputStream(file);
            ObjectInputStream ois = new ObjectInputStream(fis);
            Main.t1 = (Triangle) ois.readObject();
            ois.close();
        } else {
            Main.t1 = new Triangle(
                    new Point(100,30),
                    new Point(150,100),
                    new Point(50,100));
        }
        Main.r1 = new Rectangle(
                new Point(100,230),
                new Point(50,260),
                new Point(50,300),
                new Point(200,300)
        );
        frame.add(Main.p);
        JButton button = new JButton("三角形を移動");
        button.addActionListener(new MoveActionListener());
        Main.p.add(button);
        JButton button2 = new JButton("保存");
        button2.addActionListener(new SaveActionListener());
        Main.p.add(button2);
        frame.setVisible(true);
    }
}

class MyPanel extends JPanel {

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        Main.t1.draw(g);
        Main.r1.draw(g);
    }
}
