import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.function.Function;
import java.util.function.Predicate;

public class Main {


    public static void main(String[] args) {
        Fruits f1 = new Fruits(199, "japan","red");
        Fruits f2 = new Fruits(199, "japan","red");
        Apple ap1 = new Apple(199, "japan","red","美味しい");
        Apple ap2 = new Apple(199, "japan","red", "美味しい");

        HashSet<Fruits> hf1 = new HashSet<>();
        hf1.add(f1);
        HashSet<Fruits> hf2 = new HashSet<>();
        hf2.add(f2);
        Pair<String> sp = new Pair<>("a", "b");
        Pair2<String, Integer> sip = new Pair2<>("a", 1);
        FruitsPair<Fruits> fp = new FruitsPair<>(f1, f2);
        FruitsPair<Apple> app1 = new FruitsPair<>(ap1, ap2);
        FruitsPair<Fruits> app2 = new FruitsPair<>(ap1, ap2);
        System.out.println(f1.equals(f2));
        System.out.println(hf1.equals(hf1));
        System.out.println(hf1.equals(hf2));
        System.out.println(sip);
        System.out.println(fp);
        System.out.println(app1);
        System.out.println(app2);
    }
}