import  java.util.*;
import java.awt.Point;

public class Main {
    public static void main(String[] args) throws Exception {
        System.out.println(Math.PI);
        Point p = new Point();
        p.x = 10;
        p.y = 30;
        System.out.println(p);
        System.out.println(p.x);
        System.out.println(p.y);

        String str = String.valueOf(3);
        System.out.println(str);

        int i = Integer.parseInt("14");
        System.out.println(i);

        System.out.println(Integer.parseInt("111"));

        Date d = new Date();
        long l = d.getTime();
        System.out.println(l);
        long sec = l / 1000 ;
        long mininute = sec / 60;
        long hour = mininute / 60;
        long day = hour / 24;
        long year = day /365;
        System.out.println(year);
    }
}
