import java.util.ArrayList;
import java.util.Arrays;

public class person {
    public static <Person> void main(String[] args){

        Person p1 = new Person(age:10);
        Person p2 = new Person(age:20);
        System.out.println(p1.getPerson());
        System.out.println(Person.getName());
    }
}