import java.util.*;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

public class DateUtil {


    //prac10 getDaysBetweenをcountDaysBetweenにrename
    public static int countDaysBetween(Date from, Date to) {
        int i = 0;
        while (!addDaysToDate(from, i).equals(to)) {
            i++;
        }
        return i;
    }

}
