package org.example;

import jdk.jfr.Category;

public abstract class menu {

    int id;
    int price;
    String name;
    Category category;

    menu(int id, int price, String name, Category category){
        this.id = id;
        this.price = price;
        this.name = name;
        this.category = category;

    }

}


