package org.example;

public class table {

    int number;
    boolean isUsing;
    int guestNum;

    table(int number) {
        this.number = number;
        this.isUsing = false;
    }
}
